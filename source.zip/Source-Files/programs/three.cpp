#include <iostream>
#include <thread>
#include <chrono>
#include <queue>
#include <string>

using namespace std;

// access points for wait and signal
enum Semaphore {
    chairHallwaySem,
};

// access points for acquire and release
enum Mutex {
    taMut,
    criticalSection
};

struct SharedMemory {
    int taMutex = 1;
    int criticalSection = 1;
    int chairHallwaySemaphore = 0;
    int numOfChairsHallway = 3;
    // we will use a queue for students in hallway so that first student will be served first
    queue<string *> studentsInHallway;
    // TA queue will only ever be max size 1, but this makes it easy to push student into the
    // TAs office and pop them out once they are done
    queue<string *> studentWithTa;
} sMem;

void wait(SharedMemory *sharedMemory, Semaphore toAccess) {
    switch (toAccess) {
        case chairHallwaySem:
            if (sharedMemory->chairHallwaySemaphore < sharedMemory->numOfChairsHallway) {
                sharedMemory->chairHallwaySemaphore++;
            }
            break;
    }
}

void acquire(SharedMemory *sharedMemory, Mutex toAccess) {
    switch(toAccess) {
        case taMut:
            if(sharedMemory->taMutex == 1) {
                sharedMemory->taMutex = 0;
            }
            break;
        case criticalSection:
            if(sharedMemory->criticalSection == 1) {
                sharedMemory->criticalSection = 0;
            }
            break;
    }
}

void signal(SharedMemory *sharedMemory, Semaphore toAccess) {
    switch(toAccess) {
        case chairHallwaySem:
            if (sharedMemory->chairHallwaySemaphore > 0) {
                sharedMemory->chairHallwaySemaphore--;
            }
            break;
    }
}

void release(SharedMemory *sharedMemory, Mutex toAccess) {
    switch(toAccess) {
        case taMut:
            if(sharedMemory->taMutex == 0) {
                sharedMemory->taMutex = 1;
            }
            break;
        case criticalSection:
            if(sharedMemory->criticalSection == 0) {
                sharedMemory->criticalSection = 1;
            }
            break;
    }
}

void setNumHallwayChairs(SharedMemory *sharedMemory, int numChairs) {
    sharedMemory->numOfChairsHallway = numChairs;
}

void enterHallway(SharedMemory *sharedMemory, string *student) {
    acquire(sharedMemory, criticalSection);
    // do not admit students into the hallway if it is full
    if (sharedMemory->chairHallwaySemaphore >= sharedMemory->numOfChairsHallway) {
        cout << "Hallway is full..." + *student + " did not enter\n";
        cout.flush();
    }
    // allow students to enter the hallway otherwise
    else {
        cout << *student + " has sat down in the hallway\n";
        wait(sharedMemory, chairHallwaySem);
        sharedMemory->studentsInHallway.push(student);
        cout.flush();
    }

    release(sharedMemory, criticalSection);
}

string* enterTaOffice(SharedMemory *sharedMemory) {
    // only enter TA office if the TA is not busy
    if (sharedMemory->taMutex == 1) {
        string *studentFromHallway = sharedMemory->studentsInHallway.front();
        cout << *studentFromHallway + " has entered TA's office\n";
        cout.flush();
        sharedMemory->studentsInHallway.pop();
        sharedMemory->studentWithTa.push(studentFromHallway);
        signal(sharedMemory, chairHallwaySem);

        return studentFromHallway;
    }
    else {
        return NULL;
    }

}

void taHelpStudent(SharedMemory *sharedMemory) {
    string *student = enterTaOffice(sharedMemory);
    cout << "TA started helping " + *student + "\n";
    cout.flush();

    // this sleep will be the amount of time that the TA is spending with student
    this_thread::sleep_for(chrono::seconds(2));
    cout << "TA finished helping " + *student + "\n";
    cout.flush();
    cout << *student + " has left the TA's office\n";
    cout.flush();
    sharedMemory->studentWithTa.pop();
    release(sharedMemory, taMut);
}

void* ta(void *sharedMemory) {
    SharedMemory *memory = (struct SharedMemory *) sharedMemory;
    while(true) {
        if(memory->criticalSection == 1) {
            // only help student when the hallway is not empty and TA is not already
            // busy with a student
            if (memory->chairHallwaySemaphore > 0 && memory->taMutex == 1) {
                taHelpStudent(memory);
            }
        }
    }

    return NULL;
}

void* producer(void *sharedMemory) {
    SharedMemory *memory = (struct SharedMemory *) sharedMemory;
    bool run = true;

    while (true) {
        // only run when not finished producing
        if (run) {
            // array of student names
            string students[26] = {"Alpha", "Bravo", "Charlie", "Delta", "Echo",
                                "Foxtrot", "Golf", "Hotel", "India", "Juliet",
                                "Kilo", "Lima", "Mike", "November", "Oscar",
                                "Papa", "Quebec", "Romeo", "Sierra", "Tango",
                                "Uniform", "Victor", "Whisky", "X-Ray", "Yankee",
                                "Zulu"};

            // keep waiting to add students until critical section is free
            bool run1 = true;
            while(run1) {
                if (memory->criticalSection == 1) {
                    acquire(memory, criticalSection);
                    enterHallway(memory, &students[0]);
                    enterHallway(memory, &students[1]);
                    enterHallway(memory, &students[2]);
                    enterHallway(memory, &students[3]);
                    enterHallway(memory, &students[4]);
                    release(memory, criticalSection);
                    run1 = false;
                }
            }

            // wait some time until adding more students
            this_thread::sleep_for(chrono::seconds(6));

            // keep waiting to add students until critical section is free
            bool run2 = true;
            while(run2) {
                if(memory->criticalSection == 1) {
                    acquire(memory, criticalSection);
                    enterHallway(memory, &students[5]);
                    enterHallway(memory, &students[6]);
                    enterHallway(memory, &students[7]);
                    enterHallway(memory, &students[8]);
                    enterHallway(memory, &students[9]);
                    release(memory, criticalSection);
                    run2 = false;
                }
            }

            //prevent from running again
            run = false;
        }
    }
    
    return NULL;
}

int main() {
    cout << "\nNOTE: Threads will continue to run even after last student leaves\n";
    cout << "After last student leaves program will hang\n\n";

    SharedMemory *sharedMemory = &sMem;

    // change second argument value to change number of chairs
    setNumHallwayChairs(sharedMemory, 5);

    // two threads - producer=students entering hallway, consumer=TA
    pthread_t tidTa;
    pthread_t tidProducer;
    pthread_attr_t attrTa;
    pthread_attr_t attrProducer;

    pthread_attr_init(&attrTa);
    pthread_attr_init(&attrProducer);
    pthread_create(&tidTa, &attrTa, ta, sharedMemory);
    pthread_create(&tidProducer, &attrProducer, producer, sharedMemory);

    pthread_join(tidTa, NULL);
    pthread_join(tidProducer, NULL);

    return 0;
}